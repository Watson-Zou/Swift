//
//  WBHomeViewController.swift
//  新浪微博
//
//  Created by Watson on 2017/3/8.
//  Copyright © 2017年 Watson. All rights reserved.
//

import UIKit

//定义全局变量，尽量使用private修饰，否则到处都可以访问
//原创微博可重用cell id
private let originalCellID = "originalCellID"
/// 被转发微博的可重用 cell id
private let retweetedCellID = "retweetedCellID"


class WBHomeViewController: WBBaseViewController {

    
    //列表视图模型
    lazy var listViewModel = WBStatusListViewModel()
    
    //加载数据
    override func loadData() {
        
        refreshControl?.beginRefreshing()
        
        //模拟演示加载数据
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 2){
        
            self.listViewModel.loadStatus(pullup: self.isPullup) { (isSuccess,shouldRefresh) in
                
                print("加载数据结束")
                //数据加载完成 结束刷新控件
                self.refreshControl?.endRefreshing()
                //恢复上拉刷新标记
                self.isPullup = false
                if shouldRefresh {
                    //刷新表格
                    self.tableView?.reloadData()
                }
            }
        }
        
        
        
        //用网络工具加载微博数据
//        WBNetworkManager.shared.statusList { (list, isSuccess) in
//            
//            //字典转模型，绑定表格数据
//            print(list ?? "")
//        }
        
        
//        let urlString = "https://api.weibo.com/2/statuses/home_timeline.json"
//        let params = ["access_token":"2.002qfrDCmADcrBbe51e3a47f08Srzc"]
//        WBNetworkManager.shared.request(URLString: urlString, parameters: params as [String : AnyObject], completion: {
//            (json,isSuccess)->() in
//            print(json ?? "")
//        })
        
//        WBNetworkManager.shared.get(urlString, parameters: params, progress: nil, success: { (_, json) in
//            print(json ?? "xxxxxxxxxx")
//        }) { (_, error) in
//            print(error)
//        }
        
        
//        //模拟‘延时’加载数据 ->dispatch_after
//        //在闭包里面要用self
//        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 2) {
//            
//            for i in 0..<10 {
//                if self.isPullup {
//                    //将数据追加到底部
//                    self.statusList.append("上拉\(i.description)")
//                }else{
//                    //将数据插入到数组的顶部
//                    self.statusList.insert(i.description, at: 0)
//                }
//                
//            }
//            print("加载数据结束")
//            //数据加载完成 结束刷新控件
//            self.refreshControl?.endRefreshing()
//            //恢复上拉刷新标记
//            self.isPullup = false
//            //刷新表格
//            self.tableView?.reloadData()
//        }
        
    }
    //显示好友 @objc private
    func showFriends() -> () {
        print(#function)
        
        let vc = WBDemoViewController()
        
        //push的时候隐藏tabbar push动作是UINavigationController的，所以可以重写push的方法
        //vc.hidesBottomBarWhenPushed = true
        navigationController?.pushViewController(vc, animated: true)
        
        
    }
    

}

//MARK: - 表格的数据源方法,具体的数据源方法实现，不需要super
extension WBHomeViewController{
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return listViewModel.statusList.count
    }
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        //0.取出视图模型，根据视图模型判断可重用cell
        let vm = listViewModel.statusList[indexPath.row]
        
        let cellID = (vm.status.retweeted_status != nil) ? retweetedCellID : originalCellID
        
        
        //1.取cell - 本身会调用代理方法（如果有）
        //2.如果没有，找到cell，按照自动布局的规则，从上向下计算，找到向下的约束，从而计算动态行高
        let cell = tableView.dequeueReusableCell(withIdentifier: cellID, for: indexPath) as! WBStatusCell
        
        //2.设置cell
        cell.viewModel = vm
        
        //设置代理 
        //如果用block需要在数据源方法中，给每一个cell设置block
        //设置代理只是传递了一个指针地址，对内存空间来说更合理
        cell.delegate = self

        //3.返回cell
        return cell
    }
    //父类必须实现代理方法，子类才可以重新，wsift3.0才是如此，2.0不学
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        //1.根据indexpath,获取视图模型
        let vm = listViewModel.statusList[indexPath.row]
        
        //2.返回计算高端
        return vm.rowHeight
        
    }
}

//MARK: - WBStatusCellDelegate
extension WBHomeViewController:WBStatusCellDelegate {

    func statusCellDidSelectURLString(cell: WBStatusCell, urlString: String) {
        
        let vc = WBWebViewController()
        vc.urlString = urlString
        navigationController?.pushViewController(vc, animated: true)
        
    }
}

//MARK: - 设置界面
extension WBHomeViewController{
    
    override func setupTableView() {
        super.setupTableView()
        
        //设置导航栏按钮 系统的方法没有高亮状态
        //navigationItem.leftBarButtonItem = UIBarButtonItem(title: "好友", style: .plain, target: self, action: #selector(showFriends))
        
        //swift调用oc返回instancetype的方法，判读不出是否可选
        navItem.leftBarButtonItem = UIBarButtonItem(title: "好友", target: self, action: #selector(showFriends))
        
        //注册原型cell,swift用self
        //tableView?.register(UITableViewCell.self, forCellReuseIdentifier: cellID)
        tableView?.register(UINib(nibName: "WBStatusNormalCell", bundle: nil), forCellReuseIdentifier: originalCellID)
        tableView?.register(UINib(nibName: "WBStatusRetwwtedCell", bundle: nil), forCellReuseIdentifier: retweetedCellID)
        
        //设置行高
        tableView?.estimatedRowHeight = 300
        //取消自动行高
        //tableView?.rowHeight = UITableViewAutomaticDimension
        
        //取消分割线
        tableView?.separatorStyle = .none
        
        setupNaviTitle()
        
    }
    private func setupNaviTitle(){
        
        let title = WBNetworkManager.shared.userAccount.screen_name
        
        let button = WBTitleButton(title:title)
        
        navItem.titleView = button
        
        button.addTarget(self, action: #selector(clickTitleButton(btn:)), for: .touchUpInside)
        
    }
    
    @objc func clickTitleButton(btn:UIButton){
    
        //设置选中状态
        btn.isSelected = !btn.isSelected
        
        
    }
    
}
