//
//  WBTitleButton.swift
//  新浪微博
//
//  Created by Watson on 2017/3/18.
//  Copyright © 2017年 Watson. All rights reserved.
//

import UIKit

class WBTitleButton: UIButton {

    //重载构造函数
    //title如果是nil。就显示首页
    //如果不为nil，显示title和箭头
    
    init(title:String?) {
        super.init(frame: CGRect())
        
        //1.判断title是否为nil
        if title == nil {
            setTitle("首页", for: .normal)
        }else{
            setTitle(title! + " ", for: .normal)
            
            //设置图片
            setImage(UIImage(named:"navigationbar_arrow_down"), for: .normal)
            setImage(UIImage(named:"navigationbar_arrow_up"), for: .selected)
        }
        //2.设置字体和颜色 - 加粗
        titleLabel?.font = UIFont.boldSystemFont(ofSize: 17)
        setTitleColor(UIColor.darkGray, for: .normal)
        
        //3.设置大小
        sizeToFit()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    //重新布局子视图
    override func layoutSubviews() {
        super.layoutSubviews()
        
        //判断lable和imageview是否同事存在
        guard let titleLable = titleLabel,let imageView = imageView else {
            
            return
        }
        
        let labelWidth = titleLable.frame.size.width
        let imageWidth = imageView.frame.size.width
        
        //将imageview的x向右移动lable的宽度
        //方法一：
        imageEdgeInsets = UIEdgeInsetsMake(0, labelWidth, 0, -labelWidth)
        //将lable的x向左移动imageview的宽度
        titleEdgeInsets = UIEdgeInsetsMake(0, -imageWidth, 0, imageWidth)
        
        
       
        /*
          方法二
         
         - oc中不允许直接修改结构体内部的值，要先取出该值，修改后再设回去
         - swift中可以
         
         titleLable.frame.origin.x = 0
         imageView.frame.origin.x = titleLable.bounds.width
         
         */
    }
    
    
}
