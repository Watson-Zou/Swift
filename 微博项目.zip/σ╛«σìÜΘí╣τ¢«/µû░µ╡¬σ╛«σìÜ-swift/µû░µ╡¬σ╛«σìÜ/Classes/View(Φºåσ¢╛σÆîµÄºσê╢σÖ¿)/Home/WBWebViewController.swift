//
//  WBWebViewController.swift
//  新浪微博
//
//  Created by Watson on 2017/6/11.
//  Copyright © 2017年 Watson. All rights reserved.
//

import UIKit

//网页控制器
class WBWebViewController: WBBaseViewController {

    lazy var webView = UIWebView(frame: UIScreen.main.bounds)
    
    var urlString:String? {
    
        didSet {
            
            guard let urlString = urlString,
            let url = URL(string: urlString) else {
                return
            }
            
            webView.loadRequest(URLRequest(url: url))
        }
    }
    
}

extension WBWebViewController {

    override func setupTableView() {

        //设置标题
        navItem.title = "网页"
        
        //设置webView
        view.insertSubview(webView, belowSubview: navigationBar)
        
        webView.backgroundColor = UIColor.white
        
        //设置contentinset
        webView.scrollView.contentInset.top = navigationBar.bounds.height
    }
}
