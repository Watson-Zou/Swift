//
//  WB StatusCell.swift
//  新浪微博
//
//  Created by Watson on 2017/3/20.
//  Copyright © 2017年 Watson. All rights reserved.
//

import UIKit

//微博cell的协议
/*如果需要设置可选协议方法
 1.需要遵守 NSObjectProtocol
 2.协议需要是 @objc
 3.方法需要   @objc optional
 
 */

@objc protocol WBStatusCellDelegate: NSObjectProtocol {
    
    //微博cell选中url字符串
    @objc optional func statusCellDidSelectURLString(cell:WBStatusCell,urlString:String)

}

//微博cell
class WBStatusCell: UITableViewCell {

    //代理属性
    weak var delegate:WBStatusCellDelegate?
    
    //利用模型属性set方法设置值
    var viewModel:WBStatusViewModel?{
        
        didSet{
    
            //微博文本
            statusLabel?.attributedText = viewModel?.statusAttrText
            /// 设置被转发微博的文字
            retweetedLabel?.attributedText = viewModel?.retweetedAttrText
            //姓名
            nameLabel.text = viewModel?.status.user?.screen_name
            //设置会员图标 - 直接获取属性，不需要计算，优化性能
            memberIconView.image = viewModel?.memberIcon
            //认证图标
            vipIconView.image = viewModel?.vipIcon
            //用户头像
            iconView.cz_setImage(urlString: viewModel?.status.user?.profile_image_url, placeholderImage: UIImage(named: "avatar_default_big"),isAvatar: true)
            //底部工具栏
            toolBar.viewModel = viewModel
            
            //配图视图视图模型
            pictureView.viewModel = viewModel
            
            /// 测试配图视图的高度
            //pictureView.heightCons.constant = viewModel?.pictureViewSize.height ?? 0
            
            
            //测试4张图像
//            if (viewModel?.status.pic_urls?.count)! > 4 {
//                
//                //修改数组 -》将末尾的数据全部删除
//                var picURLs = viewModel?.status.pic_urls
//                
//                picURLs?.removeSubrange(((picURLs?.startIndex)! + 4)..<(picURLs?.endIndex)!)
//                pictureView.urls = picURLs
//                
//            }else{
//                //设置配图视图的url数据
//                pictureView.urls = viewModel?.status.pic_urls
//            }
           // pictureView.urls = viewModel?.status.pic_urls
            
            //设置来源
            sourceLabel.text = viewModel?.status.source
//sourceLabel.text = viewModel?.sourceStr
        }
        
    }
    
    
    /// 头像
    @IBOutlet weak var iconView: UIImageView!
    /// 姓名
    @IBOutlet weak var nameLabel: UILabel!
    /// 会员图标
    @IBOutlet weak var memberIconView: UIImageView!
    /// 时间
    @IBOutlet weak var timeLabel: UILabel!
    /// 来源
    @IBOutlet weak var sourceLabel: UILabel!
    /// 认证图标
    @IBOutlet weak var vipIconView: UIImageView!
    /// 微博正文
    @IBOutlet weak var statusLabel: FFLabel!
    /// 底部工具栏
    @IBOutlet weak var toolBar: WBStatusToolBar!
    
    /// 配图视图
    @IBOutlet weak var pictureView: WBStatusPictureView!
    
    /// 被转发微博的标签 -- 原创微博没有此控件，所以一定要用 ？
    @IBOutlet weak var retweetedLabel: FFLabel?
    
    
    override func awakeFromNib() {
        super.awakeFromNib()

        //离屏渲染 - 异步绘制 
        //在进入屏幕前，绘制号表格的cell，进入之后，直接显示
        //好处：运行更快  坏处：cup消耗大
        self.layer.drawsAsynchronously = true
        
        //栅（zha）格化 - 异步绘制之后，会生成一张独立的图像，cell在屏幕上滚动的时候，本质上滚动的就是这张图片
        //cell优化，尽量减少图层的数量，利用栅格化相当于只有一层
        //停止滚动之后，可以接受监听
        self.layer.shouldRasterize = true
        
        //使用 栅格化 必须注意指定分辨率
        self.layer.rasterizationScale = UIScreen.main.scale
        
        //设置微博文本代理
        statusLabel.delegate = self
        retweetedLabel?.delegate = self
    
    }

}

extension WBStatusCell: FFLabelDelegate {

    func labelDidSelectedLinkText(label: FFLabel, text: String) {
        
        //判断是否是url
        if !text.hasPrefix("http://") {
            return
        }

        // statusCellDidSelectURLString?
        //插入 ？ 代表如果代理没有实现协议方法，就什么都不做-----可选解包
        //如果使用 ！ 代表没有实现协议方法，仍然强行执行，会崩溃----强行解包
        delegate?.statusCellDidSelectURLString?(cell: self, urlString: text)
    
    }
}
