//
//  WBStatusPictureView.swift
//  新浪微博
//
//  Created by Watson on 2017/3/23.
//  Copyright © 2017年 Watson. All rights reserved.
//

import UIKit

class WBStatusPictureView: UIView {

    var viewModel:WBStatusViewModel?{
    
        didSet{
            calcViewSize()
            
            //设置urls
            urls = viewModel?.picURLs
        }
    }
    
    /// 根据视图模型的配图大小，调整显示内容
    private func calcViewSize(){
    
        //处理宽度
        //1>单图，根据配图视图的大小，修改subview[0]的宽高
        if viewModel?.picURLs?.count == 1 {
            let viewSize = viewModel?.pictureViewSize ?? CGSize()
            
            //a)获取第0个图像视图
            let v = subviews[0]
            v.frame = CGRect(x: 0,
                             y: WBStatusPictureViewOutterMargin,
                             width: viewSize.width,
                             height: viewSize.height - WBStatusPictureViewOutterMargin)
            
            
        }else{
        //2>多图，恢复subview[0]视图的宽高，保证九宫格的完整
            let v = subviews[0]
            v.frame = CGRect(x: 0,
                             y: WBStatusPictureViewOutterMargin,
                             width: WBStatusPictureItemWidth,
                             height: WBStatusPictureItemWidth)
            
        }
        
        //修改高度约束
        heightCons.constant = viewModel?.pictureViewSize.height ?? 0

    }
    
    /// 配图视图的数组
    private var urls:[WBStatusPicture]?{
    
        didSet{
            
            //1.隐藏所有的imageview
            for v in subviews {
                v.isHidden = true
            }
            //2.遍历urls数组，顺序设置图像
            var index = 0
            for url in urls ?? [] {
                
                //获取对应索引的imageview
                let iv = subviews[index] as! UIImageView
                
                //4张图像处理
                if index == 1 && urls?.count == 4 {
                    
                    index += 1
                }
                //设置图像
                iv.cz_setImage(urlString: url.thumbnail_pic, placeholderImage: nil)
                //显示图像
                iv.isHidden = false
                
                index += 1
                
                
            }
            
            
        }
    }
    
    
    @IBOutlet weak var heightCons:NSLayoutConstraint!
    
    override func awakeFromNib() {
        
        setupUI()
    }
    
    
}

extension WBStatusPictureView{

    //1.cell中所有的控件都是提前准备好
    //2.设置的时候，根据数据据定是否显示
    //3.不要动态创建控件
    func setupUI() {
        
        //设置背景颜色
        backgroundColor = superview?.backgroundColor
        
        /// 超出边界的内容不显示
        clipsToBounds = true
        
        let count = 3
        let rect = CGRect(x: 0,
                          y: WBStatusPictureViewOutterMargin,
                          width: WBStatusPictureItemWidth,
                          height: WBStatusPictureItemWidth)
        
        //循环创建9个imageview
        for i in 0..<count * count {
            
            let iv = UIImageView()
            
            //设置图片contentmodel
            iv.contentMode = .scaleAspectFill
            iv.clipsToBounds = true
            
            //行 -> y
            let row = CGFloat(i / 3)
            //列 -> x
            let col = CGFloat(i % count)
            
            let xOffset = col * (WBStatusPictureItemWidth + WBStatusPictureViewInnerMargin)
            let yOffset = row * (WBStatusPictureItemWidth + WBStatusPictureViewOutterMargin)
            
            iv.frame = rect.offsetBy(dx: xOffset, dy: yOffset)
            
            addSubview(iv)
            
            
            
        }
        
    }

}
