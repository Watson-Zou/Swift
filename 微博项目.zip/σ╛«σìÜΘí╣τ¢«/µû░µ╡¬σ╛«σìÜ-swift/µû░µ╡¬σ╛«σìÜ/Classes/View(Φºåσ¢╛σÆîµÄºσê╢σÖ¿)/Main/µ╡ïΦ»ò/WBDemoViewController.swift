//
//  WBDemoViewController.swift
//  新浪微博
//
//  Created by Watson on 2017/3/9.
//  Copyright © 2017年 Watson. All rights reserved.
//

import UIKit

class WBDemoViewController: WBBaseViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        title = "第\(navigationController?.childViewControllers.count ?? 0)个"
    
    
    }
    
    func showNext() -> () {
        
        let vc = WBDemoViewController()
        
        navigationController?.pushViewController(vc, animated: true)
        
        
    }
    
    
    
}
extension WBDemoViewController{

    override func setupTableView() {
        super.setupTableView()
        //设置右侧的控制器
        //navigationItem.rightBarButtonItem = UIBarButtonItem(title: "下一个", style: .plain, target: self, action: #selector(showNext))
        navItem.rightBarButtonItem = UIBarButtonItem(title: "下一个", target: self, action: #selector(showNext))
    }
}
