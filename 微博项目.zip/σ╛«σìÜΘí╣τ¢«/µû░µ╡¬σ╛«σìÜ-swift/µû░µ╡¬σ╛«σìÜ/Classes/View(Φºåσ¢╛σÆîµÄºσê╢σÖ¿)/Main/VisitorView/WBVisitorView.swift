//
//  WBVisitorView.swift
//  新浪微博
//
//  Created by Watson on 2017/3/10.
//  Copyright © 2017年 Watson. All rights reserved.
//

import UIKit

//访客视图
class WBVisitorView: UIView {

    //访客视图的信息字典 [imageName\message]
    //提升：如果是首页，imageName = ""
    //字典可选，重写setter方法
    var visitorInfo:[String:String]?{
        didSet {
            //1>取字典信息
            guard let imageName = visitorInfo?["imageName"],
                let message = visitorInfo?["message"] else {
                    return
            }
            
            //2>设置信息
            tipLabel.text = message
            
            //3>设置图像，首页不需要设置
            if imageName == "" {
                
                startAnimition()
                return
            }
            iconView.image = UIImage(named: imageName)
            
            //其它控制器的访客视图不需要显示小房子和遮罩视图
            houseIconView.isHidden = true
            maskIconView.isHidden = true
            
        }
    }
    
    
    //MARK: - 构造函数
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        setupUI()
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    //旋转图标动画(只有首页需要)
    private func startAnimition(){
        let anim = CABasicAnimation(keyPath: "transform.rotation")
        anim.toValue = 2 * Double.pi//M_PI已弃用
        anim.repeatCount = MAXFLOAT
        anim.duration = 15//旋转一圈的时间
        //动画完成不删除，如果iconview被释放，动画会一起销毁
        //不添加这个属性，在进入后台回来后就会停止
        //在设置连续播放的动画非常有用
        anim.isRemovedOnCompletion = false
        //将动画添加到图层上面
        iconView.layer.add(anim, forKey: nil)
        
    }
    
    //MARK: - 私有控件(一般写在init下面，重要公开的方法写在init上面，方便别人阅读)
    //懒加载属性只有调用UIKit控件的制定构造函数，其它都需要使用类型
    //图像视图  private
     lazy var iconView = UIImageView(image:UIImage(named: "visitordiscover_feed_image_smallicon"))
    
    //遮罩图像 注意位置
    lazy var maskIconView = UIImageView(image: UIImage(named: "visitordiscover_feed_mask_smallicon"))
    
    //小房子   private
    lazy var houseIconView = UIImageView(image:UIImage(named: "visitordiscover_feed_image_house"))
    //提示标签 private
     lazy var tipLabel:UILabel = UILabel.cz_label(
        withText: "关注一些人，回这里看看有什么惊喜关注一些人，回这里看看有什么惊喜",
        fontSize: 14,
        color: UIColor.darkGray)
    //注册按钮  private
     lazy var registerButton:UIButton = UIButton.cz_textButton(
        "注册",
        fontSize: 16,
        normalColor: UIColor.orange,
        highlightedColor: UIColor.black,
        backgroundImageName:"common_button_white_disable")
    //登录按钮 private
      lazy var loginButton:UIButton = UIButton.cz_textButton(
        "登录",
        fontSize: 16,
        normalColor: UIColor.darkGray,
        highlightedColor: UIColor.black,
        backgroundImageName:"common_button_white_disable")

}

//MARK:-设置界面
extension WBVisitorView{
    
    func setupUI() {
        //0.在开发的时候，如果能用颜色，就不要使用图片，颜色效率高
        backgroundColor = UIColor.cz_color(withHex: 0xEDEDED)
        
        //文本居中
        tipLabel.textAlignment = .center
        
        //1.添加控件
        addSubview(iconView)
        addSubview(maskIconView)
        addSubview(houseIconView)
        addSubview(tipLabel)
        addSubview(registerButton)
        addSubview(loginButton)
        
        //2.取消autoresing
        for v in subviews {
            v.translatesAutoresizingMaskIntoConstraints = false
        }
        
        //3.利用苹果原生自动布局
        let margin:CGFloat = 20.0
        
        //(item view1: 视图, attribute attr1: 约束属性, relatedBy relation: 约束关系, toItem view2: 参照视图, attribute attr2: 参照属性, multiplier: 乘积, constant c: 加上的约束熟知)
        
        //如果指定宽、高约束
            //1.参照视图设置为nil
            //2.参照属性选择notAnAttribute
 
        //1>图像视图
        addConstraint(NSLayoutConstraint(item: iconView,
                                         attribute: .centerX,
                                         relatedBy: .equal,
                                         toItem: self,
                                         attribute: .centerX,
                                         multiplier: 1.0,
                                         constant: 0))
        addConstraint(NSLayoutConstraint(item: iconView,
                                         attribute: .centerY,
                                         relatedBy: .equal,
                                         toItem: self,
                                         attribute: .centerY,
                                         multiplier: 1.0,
                                         constant: -60))
        //2>小房子
        addConstraint(NSLayoutConstraint(item: houseIconView,
                                         attribute: .centerX,
                                         relatedBy: .equal,
                                         toItem: iconView,
                                         attribute: .centerX,
                                         multiplier: 1.0,
                                         constant: 0))
        addConstraint(NSLayoutConstraint(item: houseIconView,
                                         attribute: .centerY,
                                         relatedBy: .equal,
                                         toItem: iconView,
                                         attribute: .centerY,
                                         multiplier: 1.0,
                                         constant: 0))
        //3>提示标签
        addConstraint(NSLayoutConstraint(item: tipLabel,
                                         attribute: .centerX,
                                         relatedBy: .equal,
                                         toItem: iconView,
                                         attribute: .centerX,
                                         multiplier: 1.0,
                                         constant: 0))
        addConstraint(NSLayoutConstraint(item: tipLabel,
                                         attribute: .top,
                                         relatedBy: .equal,
                                         toItem: iconView,
                                         attribute: .bottom,
                                         multiplier: 1.0,
                                         constant: margin))
        addConstraint(NSLayoutConstraint(item: tipLabel,
                                         attribute: .width,
                                         relatedBy: .equal,
                                         toItem: nil,
                                         attribute: .notAnAttribute,
                                         multiplier: 1.0,
                                         constant: 236))
        //4>注册按钮 没有设置高度，以按钮的背景图片高度作为按钮的高度
        addConstraint(NSLayoutConstraint(item: registerButton,
                                         attribute: .left,
                                         relatedBy: .equal,
                                         toItem: tipLabel,
                                         attribute: .left,
                                         multiplier: 1.0,
                                         constant: 0))
        addConstraint(NSLayoutConstraint(item: registerButton,
                                         attribute: .top,
                                         relatedBy: .equal,
                                         toItem: tipLabel,
                                         attribute: .bottom,
                                         multiplier: 1.0,
                                         constant: margin))
        addConstraint(NSLayoutConstraint(item: registerButton,
                                         attribute: .width,
                                         relatedBy: .equal,
                                         toItem: nil,
                                         attribute: .notAnAttribute,
                                         multiplier: 1.0,
                                         constant: 100))
        //4>登陆按钮 没有设置高度，以按钮的背景图片高度作为按钮的高度
        addConstraint(NSLayoutConstraint(item: loginButton,
                                         attribute: .right,
                                         relatedBy: .equal,
                                         toItem: tipLabel,
                                         attribute: .right,
                                         multiplier: 1.0,
                                         constant: 0))
        addConstraint(NSLayoutConstraint(item: loginButton,
                                         attribute: .top,
                                         relatedBy: .equal,
                                         toItem: tipLabel,
                                         attribute: .bottom,
                                         multiplier: 1.0,
                                         constant: margin))
        addConstraint(NSLayoutConstraint(item: loginButton,
                                         attribute: .width,
                                         relatedBy: .equal,
                                         toItem: registerButton,
                                         attribute: .width,
                                         multiplier: 1.0,
                                         constant: 0))
    //6>遮罩图片 利用vfl
        //vfl通常用于连续参照关系，居中对齐这种不好用
        //views：定义vfl中的控件名称和实际名称映射关系
        let viewDict = ["maskIconView":maskIconView,
                        "registerButton":registerButton] as [String : Any]
        /*    
         H:|-0-[maskIconView]-0-|
            H:表示水平方向 V:表示垂直方向
            |:表示边界
            0:表示距离左边距离
            maskIconView:表示设置的控件名称
            0:表示距离右边距离
        */
        addConstraints(NSLayoutConstraint.constraints(
            withVisualFormat: "H:|-0-[maskIconView]-0-|",
            options: [],//oc中用0，swift写空数组
            metrics: nil,
            views: viewDict))//定义vfl中的控件名称和实际名称映射关系
        addConstraints(NSLayoutConstraint.constraints(
            withVisualFormat: "V:|-0-[maskIconView]-(-20)-[registerButton]",//-35表示距离registerButton按钮顶部往下距离35
            options: [],
            metrics: nil,
            views: viewDict))
    }
    
    
}





