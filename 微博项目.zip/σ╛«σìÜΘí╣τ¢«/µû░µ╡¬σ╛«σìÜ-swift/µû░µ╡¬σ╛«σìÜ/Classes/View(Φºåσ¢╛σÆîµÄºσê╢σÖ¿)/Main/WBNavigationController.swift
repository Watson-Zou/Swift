//
//  WBNavigationController.swift
//  新浪微博
//
//  Created by Watson on 2017/3/8.
//  Copyright © 2017年 Watson. All rights reserved.
//

import UIKit

class WBNavigationController: UINavigationController {

    //pop返回上一级控制器
    func popToParent(){
        
        popViewController(animated: true)
    }

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //隐藏默认的Navigationbar
        navigationBar.isHidden = true
        
    }
    
    
    //重写push方法，所有的push动作都会调用此方法
    //viewController 是被push的控制器，设置他的左侧的按钮作为返回按钮
    override func pushViewController(_ viewController: UIViewController, animated: Bool) {
        
        print(viewController)
        //如果不是栈低控制器才要隐藏，根控制器不需要处理
        if childViewControllers.count > 0{
            //隐藏底部的TabBar
            viewController.hidesBottomBarWhenPushed = true
            
            //判断控制器的类型
            if let vc = viewController as? WBBaseViewController {
                
                var title = "返回"
                
                //判断控制器的级数，只有一个子控制器的时候，显示zhandi
                if childViewControllers.count == 1 {
                    //title显示首页的标题
                    title = childViewControllers.first?.title ?? "返回"
                }
                
                //取出自定义的navItem,设置左侧按钮作为返回按钮
                vc.navItem.leftBarButtonItem = UIBarButtonItem(title: title, target: self, action: #selector(popToParent),isBack:true)
            }


        }
        
        super.pushViewController(viewController, animated: true)
    }

}
