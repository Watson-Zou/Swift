//
//  WBMainViewController.swift
//  新浪微博
//
//  Created by Watson on 2017/3/8.
//  Copyright © 2017年 Watson. All rights reserved.
//

import UIKit
import SVProgressHUD


//主控制器
class WBMainViewController: UITabBarController {

    //定时器
    var timer:Timer?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        setupChildControllers()
        setupCompseButton()
        
        setupTimer()
        
        //设置新特性视图
        setupNewFeatureViews()
        
        
        //设置代理
        delegate = self
        
        //注册通知
        NotificationCenter.default.addObserver(self, selector: #selector(userLogin), name: NSNotification.Name(rawValue: WBUserShouldLoginNotification), object: nil)
        
    }
    
    deinit {
        //销毁时钟
        timer?.invalidate()
        
        //注销通知
        NotificationCenter.default.removeObserver(self)
    }
    
    
    
    
    /*
        portrait :竖屏，肖像
        landscape :横屏，风景画
     */
    //使用代码控制设备的方向,好处，可以在需要横屏的时候，单独处理
    //设置支持的方向后，当前的控制器及子控制器都会遵守这个方向
    //如果播放视频，通常是通过modal展现的 
    //重写属性的get方法
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask{
        return .portrait
    }
    
    //MARK:-监听方法 
    @objc private func userLogin(n:Notification) {
        
        print("用户登录通知\(n)")
        
        var when = DispatchTime.now()
        
        
        //判断n.object是否有值，如果有值，提示用户重新登录
        if n.object != nil {
            
            //设置指示器渐变样式
            SVProgressHUD.setDefaultMaskType(.custom)
             SVProgressHUD.showInfo(withStatus: "用户登录已经超时，需要重新登录")
            //修改延迟时间
            when = DispatchTime.now() + 2
        }
        //延迟跳转
        DispatchQueue.main.asyncAfter(deadline: when){
            
            SVProgressHUD.setDefaultMaskType(.clear)
            
            //展现登录控制器 - 通常会和UINavigationController连用，方便返回
            let nav = UINavigationController(rootViewController:WBOAuthViewController())
            self.present(nav, animated: true, completion: nil)
        }
        
        
    }
    
    //撰写微博

     func composeStatus() {
        print("撰写微博")
        
        //0>判断是否登录
        
        //1>实例化视图 -- 调用类方法
        let v = WBComposeTypeView.composeTypeView()
        
        //2>显示视图 [weak v]弱引用，否则循环引用
        v.show {[weak v] (clsName) in
            
            //展现撰写微博控制器
            //cls命名空间
            guard let clsName = clsName,
            let cls = NSClassFromString(Bundle.main.namespace + "." + clsName) as? UIViewController.Type else{
                
                v?.removeFromSuperview() 
                return
            }
            
            let vc = cls.init()
            
            let nav = UINavigationController(rootViewController: vc)
            
            self.present(nav, animated: true, completion: { 
               
                v?.removeFromSuperview()
            })
        }
        
        
        
        
    }
    
    
    //MARK:-私有空间 避免可选，使用懒加载
    //lazy var composeButton = { ()->UIButton in
        
        //let btn:UIButton = UIButton(type:UIButtonType.custom)
        //btn.setImage(UIImage(named: "tabbar_compose_icon_add"), for: .normal)
        //btn.setBackgroundImage(UIImage(named:"tabbar_compose_button"), for: .normal)
        //btn.backgroundColor = UIColor.orange
        //return btn
    //}()
    lazy var composeButton:UIButton = UIButton.cz_imageButton("tabbar_compose_icon_add", backgroundImageName: "tabbar_compose_button")
    
}

//MARK: - 新特性视图处理
extension WBMainViewController{
    
    func setupNewFeatureViews() {
        
        //0.判断是否登录,如果不登录，什么都不干
        if !WBNetworkManager.shared.userLogon{
            
            return
        }
        
        //1.如果更新，显示新特性，否则显示欢迎
        let v = isNewVersion ? WBNewFeatureView.newFeatureView() : WBWelcomeView.welcomeView()
        //2.添加视图
        view.addSubview(v)
        
    }
    
    //extension 中可以有计算型属性，不会占用内存空间
    //构造函数：给属性分配空间
    /*
     版本号
     -在appstore每次升级应用程序，版本号都需要增加
     -组成 ： 主版本号.次版本号.修订版本号
     -主版本号：意味着大的修改，使用者也需要做大的适用
     -次版本号：意味着小的修改，某些函数和方法等使用或则参数有变化
     -修订版本号：框架／程序内部bug等修订，不会对使用者造成任何影响
     
     */
    var isNewVersion:Bool{
        
        //1.取当前的版本号 
        //as? String 转为string格式
        //String ?? "" 因为string时可选的，要解包
        let currentVersion = Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? ""
        print("当前版本" + currentVersion)
        
        //2.取保存在 document（itunes备份）【最理想保存在用户偏好】目录中的之前的版本号
        let path:String = ("version" as NSString).cz_appendDocumentDir()
        let sandboxVersion = (try? String(contentsOfFile: path)) ?? ""
        print("沙盒版本" + sandboxVersion)
        
        //3.将当前版本号保存在沙盒
        _ = try? currentVersion.write(toFile: path, atomically: true, encoding: .utf8)
        
        //4.返回两个版本号 是否一致
        return currentVersion != sandboxVersion
    }
    
}


//MARK: - UITabBarControllerDelegate
extension WBMainViewController:UITabBarControllerDelegate{
    
    /// 将要选择tabbaritem
    ///
    /// - Parameters:
    ///   - tabBarController: tabBarController
    ///   - viewController: 目标控制器
    /// - Returns: 是否切换到目标控制器
    func tabBarController(_ tabBarController: UITabBarController, shouldSelect viewController: UIViewController) -> Bool {
        
        //1>获取控制器在数组中的索引
        let index = childViewControllers.index(of: viewController)
        //2>获取当前索引,同时index也是首页，重复点击首页的按钮
        if selectedIndex == 0 && index == selectedIndex {
            
            //3>让表格滚动到顶部
            //a>获取到控制器
            let nav  = childViewControllers[0] as! UINavigationController
            let vc = nav.childViewControllers[0] as! WBHomeViewController
            
            //b>滚动到顶部 -64
            vc.tableView?.setContentOffset(CGPoint(x: 0, y: -64), animated: true)
            
            
            //4>刷新数据 - 增加延迟，保证表格先滚动到顶部再刷新
            DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 1, execute: { 
                vc.loadData()
            })
            //5>清除tabitem的badgenumber 和 icon 提醒数字
            vc.tabBarItem.badgeValue = nil //是字符串
            UIApplication.shared.applicationIconBadgeNumber = 0
        }
        
        
        //判读目标控制器是否是 UIViewController
        //isMember 判断是否是该控制器，不包括子类情况
        //这样解决容错点问题
        return !viewController.isMember(of: UIViewController.self)
    }
}

//MARK:-时钟相关方法
extension WBMainViewController{

    //定义时钟
    func setupTimer(){
    
        //时间间隔建议长一些
        timer = Timer.scheduledTimer(timeInterval: 60.0, target: self, selector: #selector(updateTimer), userInfo: nil, repeats: true)
    }
    //时钟触发方法
    @objc private func updateTimer(){
        
        if !WBNetworkManager.shared.userLogon {
            return //用户没有登陆，不再处理时钟事件
        }
        
        WBNetworkManager.shared.unreadCount { (count) in
            
            print("检测到\(count)条微博")
            //设置 首页 tabbaritem 的 badgenumber
            self.tabBar.items?[0].badgeValue = count > 0 ? "\(count)" : nil
            
            //设置app的badgenumber  从ios8.0开始，要用户授权才可以显示
            UIApplication.shared.applicationIconBadgeNumber = count
        }
        
    }
    
}


//extension 类似于oc中的分类，在swift中还可以用来切分代码块
//可以把相近功能的函数，放在一个extension中
//便于代码维护
//注意:和OC的分类一样，extension中不能定义属性
extension WBMainViewController{

    //设置撰写按钮
     func setupCompseButton(){
    
        tabBar.addSubview(composeButton)
        //计算按钮的宽度
        let count = CGFloat(childViewControllers.count)
        //把向内缩进的宽度减少，能够让按钮宽度变大，盖住容错点，防止穿帮
        let w = tabBar.bounds.width / count
        
        //相当于oc中的CGRectInset 正数向内缩进，负数向外扩展
        composeButton.frame = tabBar.bounds.insetBy(dx: 2*w, dy: 0)
        
        //按钮监听方法
        composeButton.addTarget(self, action: #selector(composeStatus), for: .touchUpInside)
    }
    
    //设置所有子控制器
    func setupChildControllers(){
        
        //0.获取沙盒json路径
        let docDir = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0]
        let jsonPath = (docDir as NSString).appendingPathComponent("main.json")
        
        //1.加载data
        var data = NSData(contentsOfFile: jsonPath)
        
        //2.判断data是否有内容，如果没有，说明本地沙盒没有文件,就加载本地预先创建好的data
        if data == nil {
            //从Bundle 加载 data
            let path = Bundle.main.path(forResource: "main.json", ofType: nil)
            data = NSData(contentsOfFile: path!)
        }
        //data 一定有内容，反序列化
        //3.反序列化转成数组
        //try? 如果解析成功就有值，否则为nil
        //try! 如果解析不成功，程序会崩溃，有风险
        
        guard let array = try? JSONSerialization.jsonObject(with: data! as Data, options: []) as? [[String:Any]]
            else {
            return
        }
        
        //在现在的很多应用程序中，界面的创建都依赖网络的json
//        let array:[[String:Any]] = [
//            
//            ["clsName":"WBHomeViewController","title":"首页","imageName":"home",
//             "visitorInfo":["imageName":"","message":"关注一些人，回这里看看有什么惊喜"]
//             ],
//            ["clsName":"WBMessageViewController","title":"消息","imageName":"message_center",
//             "visitorInfo":["imageName":"visitordiscover_image_message","message":"登陆后，别人评论你的微博，发给你的信息，都会在这里收到通知"]
//            ],
//            ["clsName":"xxx"],//预留一个空间放中间的➕按钮，因为下面有guard守护，只要有一个参数为空就不会显示字体
//            ["clsName":"WBDiscoverViewController","title":"发现","imageName":"discover",
//             "visitorInfo":["imageName":"visitordiscover_image_message","message":"登陆后，最新、最热微博尽在掌握，不再与实事潮流插肩而过"]
//            ],
//            ["clsName":"WBProfileViewController","title":"我","imageName":"profile",
//             "visitorInfo":["imageName":"visitordiscover_image_profile","message":"登陆后，你的微博、相册、个人资料会显示在这里，展示给别人"]
//            ],
//        ]
        //测试数据格式是否正确 -- 转换成plist数据更加直观
        //(array as NSArray).write(toFile: "/Users/feng/Desktop/demo.plist", atomically: true)
        
        //数组 转 json
        //[.prettyPrinted]设置json数据的格式有序，不设置传[]
//        let data = try! JSONSerialization.data(withJSONObject: array, options: [.prettyPrinted])
//        (data as NSData).write(toFile: "/Users/feng/Desktop/demo.json", atomically: true)
        
        //遍历数组，循环创建控制器数组
        var arrayM = [UIViewController]()
        for dict in array! {
            arrayM.append(controller(dict: dict))
        }
        viewControllers = arrayM
    }
    
    //使用字典创建一个子控制器
    private func controller(dict:[String:Any]) -> UIViewController {
        
        //1.取得字典内容 因为字典取值是可选的，用guard let
        guard let clsName = dict["clsName"] as? String,
            let title = dict["title"] as? String,
            let imageName = dict["imageName"] as? String,
            //1>将clsName 转换成 class 利用反射机制
            let cls = NSClassFromString(Bundle.main.namespace + "." + clsName) as? WBBaseViewController.Type,
            let visitorDict = dict["visitorInfo"] as? [String:String]
        
            
            else{
                return UIViewController()
        }
        //2.创建视图控制器
        let vc = cls.init()
        
        //3.设置title
        vc.title = title
        
        //设置控制器的访客信息字典
        vc.visitorInfoDictionary = visitorDict
        
        //4.设置图片 ?.withRenderingMode(.alwaysOriginal)渲染图片
        vc.tabBarItem.image = UIImage(named: "tabbar_"+imageName)
        vc.tabBarItem.selectedImage = UIImage(named: "tabbar_"+imageName+"_selected")?.withRenderingMode(.alwaysOriginal)
        //5.设置tabbar的标题字体颜色和大小---通过属性字典
        vc.tabBarItem.setTitleTextAttributes([NSForegroundColorAttributeName:UIColor.darkGray], for: .highlighted)
        //系统默认是12好子，修改字体大小，要设置normal的字体大小
        vc.tabBarItem.setTitleTextAttributes([NSFontAttributeName:UIFont.systemFont(ofSize: 12)], for: .normal)
        
        //实例化导航控制器的时候，会调用push方法将rootvc压栈    
        let nav = WBNavigationController(rootViewController:vc)
        
        return nav
    }
    
    
}
