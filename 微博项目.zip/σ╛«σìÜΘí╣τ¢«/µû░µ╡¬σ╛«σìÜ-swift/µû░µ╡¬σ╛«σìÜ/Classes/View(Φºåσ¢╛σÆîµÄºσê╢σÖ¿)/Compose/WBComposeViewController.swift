//
//  WBComposeViewController.swift
//  新浪微博
//
//  Created by Watson on 2017/4/10.
//  Copyright © 2017年 Watson. All rights reserved.
//

import UIKit

//撰写微博控制器
class WBComposeViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = UIColor.cz_random()
        
        navigationItem.leftBarButtonItem = UIBarButtonItem(title: "退出", target: self, action: #selector(close))
        
        

    }
    
    @objc private func close(){
        
        dismiss(animated: true, completion: nil)
    }
}
