//
//  WBProfileViewController.swift
//  新浪微博
//
//  Created by Watson on 2017/3/8.
//  Copyright © 2017年 Watson. All rights reserved.
//

import UIKit

class WBProfileViewController: WBBaseViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    
    
    }

    
}
