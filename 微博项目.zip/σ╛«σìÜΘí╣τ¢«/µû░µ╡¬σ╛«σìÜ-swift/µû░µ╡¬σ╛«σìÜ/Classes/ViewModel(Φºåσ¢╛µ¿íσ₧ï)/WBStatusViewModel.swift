//
//  WBStatusViewModel.swift
//  新浪微博
//
//  Created by Watson on 2017/3/20.
//  Copyright © 2017年 Watson. All rights reserved.
//

import Foundation

//单条微博的视图模型
/*
 如果没有任何父类，如果希望在开发时调试，输出调试信息，需要
 1.遵守CustomStringConvertible
 2.实现description计算型属性
 
 关于表格的性能优化
 -尽量少计算，所有需要的素材提前计算好
 -控件上不要设置圆角半径，所有图像渲染的属性，都要注意
 -cell中控件的层次越少越好，数量越少越好
 -不要动态创建控件，所有需要的控件，都要提前创建好，在显示的时候，根据数据隐藏／显示
 
 
 */
class WBStatusViewModel:CustomStringConvertible{
    
    //微博模型
    var status:WBStatus
    
    //会员图标 - 存储型属性（用内存换cup)
    var memberIcon:UIImage?
    //认证类型 -1:没有认证，0:认证用户，2、3、5:企业认证，220:达人
    var vipIcon:UIImage?
    
    /// 转发文字
    var retweetedStr:String?
    /// 评论文字
    var commentStr:String?
    /// 点赞文字
    var likeStr:String?
    /// 来源字符串
    //var sourceStr:String?
    
    /// 配图视图大小 默认为0
    var pictureViewSize = CGSize()
    
    /// 如果是被转发的微博，原创微博一定没有图
    var picURLs:[WBStatusPicture]?{
    
        //如果有被转发的微博，返回被转发微博的配图
        //如果没有被转发的微博，返回原创微博的配图
        //如果都没有，返回nil
        //计算型属性
        return status.retweeted_status?.pic_urls ?? status.pic_urls
    }
    //微博正文的属性文本
    var statusAttrText: NSAttributedString?
    //转发文字的属性文本
    var retweetedAttrText:NSAttributedString?
    
    
    /// 行高
    var rowHeight:CGFloat = 0
    
    
    
    /// 构造函数
    ///
    /// - Parameter model: 微博模型
    init(model:WBStatus) {
        self.status = model
        
        //设置会员等级
        if (model.user?.mbrank)! > 0 && (model.user?.mbrank)! < 7 {
            
            let imageName = "common_icon_membership_level\(model.user?.mbrank ?? 1)"
            memberIcon = UIImage(named: imageName)
        }
        //认证图标 -1.没有认证，0.认证用户,2.3.5企业认证，220:达人
        switch model.user?.verified_type ?? -1 {
        case 0:
            vipIcon = UIImage(named: "avatar_vip")
        case 2,3,5:
            vipIcon = UIImage(named: "avatar_enterprise_vip")
        case 220:
            vipIcon = UIImage(named: "avatar_grassroot")
        default:
            break
        }
        
        //设置底部计数字符串
        retweetedStr = countString(count: model.reposts_count, defaultStr: "转发")
        commentStr = countString(count: model.comments_count, defaultStr: "评论")
        likeStr = countString(count: model.attitudes_count, defaultStr: "赞")
        
        //计算配图视图大小 - 有原创的计算原创的，有转发的计算转发的
        pictureViewSize = calcPictureViewSize(count: picURLs?.count)
        
        //设置微博文本
        let originalFont = UIFont.systemFont(ofSize: 15)
        let retweetedFont = UIFont.systemFont(ofSize: 14)
        
        //微博正文的属性文本
        statusAttrText =  CZEmoticonManager.shared.emotionString(string: model.text ?? "", font: originalFont)
        
        //设置被转发微博的文字
        let rText = "@" + (status.retweeted_status?.user?.screen_name ?? "") + ":" + (status.retweeted_status?.text ?? "")
        retweetedAttrText = CZEmoticonManager.shared.emotionString(string: rText, font: retweetedFont)
        //设置来源字符串
        //sourceStr = "来自" + (model.source?.cz_href()?.text ?? "")
        //更新行高
        updateRowHeight()
        
        
    }
    
    
    var description: String{
        
        return status.description
    }
    
    /// 根据当前的视图模型内容计算行高
    func updateRowHeight() {
        //原创微博 ：顶部分割视图（12）+间距（12） + 图像的高度（34）+间距（12）+正文高度（需要计算）+配图视图高度（计算）+间距（12）+底部视图高度（35）
        
        //转发微博 ：顶部分割视图（12）+间距（12） + 图像的高度（34）+间距（12）+正文高度（需要计算）+间距（12）+间距（12）+转发文本高度（计算）+配图视图高度（计算）+间距（12）+底部视图高度（35）
        let margin:CGFloat = 12
        let iconHeight:CGFloat = 34
        let toolbarHeight:CGFloat = 35
        
        var height:CGFloat = 0
        
        let viewSize = CGSize(width: UIScreen.cz_screenWidth() - 2 * margin, height: CGFloat(MAXFLOAT))
        
        //1.计算顶部位置
        height = 2 * margin + iconHeight + margin 
        
        //2.正文属性文本的高度(属性文本中，本省已经包含了字体属性）)
        if let text = statusAttrText {
            
            height += text.boundingRect(with: viewSize, options: [.usesLineFragmentOrigin], context: nil).height
            /*
                1>预期尺寸
                2>选项，换行文本，统一使用usesLineFragmentOrigin
                3>attributes指定字体字典
                4>
             
             */
            
        }
        //3.判断是否转发微博
        if status.retweeted_status != nil {
            
            height += 2 * margin
            //转发文本的高度 -- 一定用retweetedtext，评价了@用户名：微博文字
            if let text = retweetedAttrText {
                
                height += text.boundingRect(with: viewSize, options: [.usesLineFragmentOrigin], context: nil).height
            }
        }
        //4.配图视图
        height += pictureViewSize.height
        height += margin
        
        //5.底部工具栏
        height += toolbarHeight
        
        //6.使用属性记录
        rowHeight = height

    }
    
    /// 使用单个图像，更新配图视图的大小
    ///
    /// - Parameter image: 网络缓存的单张图像
    func updataSingleImageSize(image:UIImage) {
        
        var size = image.size
        
        let maxWidth:CGFloat = 300
        let minWidth:CGFloat = 40
        
        //过宽图像处理
        if size.width > maxWidth  {
            
            //设置最大宽度
            size.width = maxWidth
            //等比例调整高度
            size.height = size.width * (image.size.height / image.size.width)
        }
        //过窄图像处理
        if size.width < minWidth {
            
            size.width = minWidth
            //要特殊处理高度，否则高度太大，会影响用户体验 等比例缩放后除以4
            size.height = size.width * (image.size.height / image.size.width) / 4
        }
        
        //特例：有些图像，本身就是很窄，很长 -》定义一个minheigth，思路同上
        //在工作中，如果看到代码中有些疑惑的分支处理，千万不要动
        
        //注意，尺寸要加上顶部的12个点的空隙，便于布局
        size.height += WBStatusPictureViewOutterMargin
        
        //重新设置配图视图的带下
        pictureViewSize = size
        
        //更新行高
        updateRowHeight()
        
    }
    
    /// 计算指定数量的图片对应的配图视图的大小
    ///
    /// - Parameter count: 配图数量
    /// - Returns: 配图视图大小
    private func calcPictureViewSize(count:Int?)->CGSize{
        
        if count == 0 || count == nil{
            return CGSize()
        }
        
        //1.计算配图视图的宽度
        //常数准备
        
        //2.计算高度
        //1>根据count知道行数
        let row = (count! - 1) / 3 + 1
        //2>根据行数算高度
        var height = WBStatusPictureViewOutterMargin
        height += CGFloat(row) * WBStatusPictureItemWidth
        height += CGFloat(row -  1) * WBStatusPictureViewInnerMargin
        
        return CGSize(width: WBStatusPictureViewWidth, height: height)
    }
    
    private func countString(count:Int,defaultStr:String)->String{
        
        if count == 0 {
            return defaultStr
        }
        
        if count < 10000 {
            return count.description
        }
        
        return String(format: "%.02f万", Double(count) / 10000)
    
    
    }
    
    
}
