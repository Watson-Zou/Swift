//
//  WBStatus.swift
//  新浪微博
//
//  Created by Watson on 2017/3/15.
//  Copyright © 2017年 Watson. All rights reserved.
//

import UIKit
import YYModel  //第三方模型管理库

//微博数据模型
class WBStatus: NSObject {

    //int类型，在64位的机器是64为，在32的机器就是32位
    // 如果不写 Int64 在 iPad2/iphone 5/5c/4c/4都无法正常运行
    var id:Int64 = 0
    
    //微博信息内容
    var text:String?
    
    /// 微博创建时间字符串
    var created_at:String?
    
    /// 微博来源 - 发布微博使用的客户端
    var source:String? {
    
        didSet {
            //重新计算来源并且保存
            //在didset中，给source再次设值，不会掉用 didset
            source = "来自于" + (source?.cz_href()?.text ?? "")
        }
    }
    
    
    /// 转发数
    var reposts_count:Int = 0
    /// 评论数
    var comments_count:Int = 0
    /// 点赞数
    var attitudes_count:Int = 0
    
    /// 微博的用户 - 注意和服务器返回的一致
    var user:WBUser?
    
    /// 微博配图模型数组
    var  pic_urls:[WBStatusPicture]?
    
    /// 被转发的原创微博
    var retweeted_status:WBStatus?
    
    
    //重写description的计算型属性
    override var description: String{
        return yy_modelDescription()
    }
    
    /// 类函数 -》告诉第三方框架 yy_model如果遇到数组类型的属性，数组中存放的对象是什么类
    //nsarray 中保存对象的类型是id类型
    //oc中的泛型是swift推出后，苹果味了兼容给oc增加的
    //从运行时角度，仍然不知道数组中应该存放什么类型的对象
    class func modelContainerPropertyGenericClass()->[String:AnyClass]{
        
        return ["pic_urls":WBStatusPicture.self]
    }
    
}
