//
//  WBStatusPicture.swift
//  新浪微博
//
//  Created by Watson on 2017/3/23.
//  Copyright © 2017年 Watson. All rights reserved.
//

import UIKit

/// 微博配图模型
class WBStatusPicture: NSObject {

    /// 缩略图地址
    var thumbnail_pic:String?
    
    override var description: String{
        
        return yy_modelDescription()    
    }
    
}
