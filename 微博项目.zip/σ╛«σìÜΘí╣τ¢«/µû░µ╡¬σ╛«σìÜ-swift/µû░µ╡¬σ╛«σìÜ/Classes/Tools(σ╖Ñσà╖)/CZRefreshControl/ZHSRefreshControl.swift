//
//  ZHSRefreshControl.swift
//  新浪微博
//
//  Created by Watson on 2017/4/5.
//  Copyright © 2017年 Watson. All rights reserved.
//

import UIKit

/// 刷新状态切换的临近点
//private let ZHSRefreshOffset:CGFloat = 60
private let ZHSRefreshOffset:CGFloat = 126 //美团刷新高度

/// 刷新状态
///
/// - Normol: 普通状态，什么都不做
/// - Pulling: 超过临界点，如果放手，开始刷新
/// - WillRefresh: 用户超过临界点，并且放手
enum ZHSRefreshState {
    case Normol
    case Pulling
    case WillRefresh
}

//刷新控件 - 负责刷新相关的逻辑处理
class ZHSRefreshControl: UIControl {

    //MARK: - 属性
    //滚动视图的父视图，下拉刷新控件应该适用于UITableView 和  UICollectionView
    //如果用strong就会循环引用  weak
    private weak var scrollView:UIScrollView?

    //懒加载创建刷新视图
    lazy var refreshView:ZHSRefreshView = ZHSRefreshView.refreshView()
    
    //MARK: - 构造函数
    init() {
        super.init(frame: CGRect())
        
        setupUI()
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    
        setupUI()
    }
    /*
     willMove 在addsubview方法会调用
     - 当添加到父视图的时候，newsuperview是父视图
     - 当父视图移除newsuperview是nil
     
     */
    override func willMove(toSuperview newSuperview: UIView?) {
        super.willMove(toSuperview: newSuperview)
        
        //判断父视图的类型
        guard let sv = newSuperview as? UIScrollView else {
            
            return
        }
        //记录父视图
        scrollView = sv
        
        //kvo监听父视图的contentoffset
        scrollView?.addObserver(self, forKeyPath: "contentOffset", options: [], context: nil)
        
        
    }
    
    //本视图从父视图上移除
    //提示：所有的下啦刷新框架都是监听父视图的contentoffset
    //所有的框架的kvo监听实现思路都是这个
    override func removeFromSuperview() {
        
        //superview还存在
        superview?.removeObserver(self, forKeyPath: "contentOffset")

        super.removeFromSuperview()
        
        //superview不存在
    
    }
    
    //所有kvo方法都会统一调用此方法 
    //在程序中，通常只监听某一个对象的某个属性，如果属性太多，方法会很乱
    //观察者模式，在不需要的时候，都需要释放
    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
        
        guard let sv = scrollView else {
            return
        }
        
        //初始高度应该是是0 contentInset在controller中设置了
        let height = -(sv.contentInset.top  + sv.contentOffset.y)
        
        //往上滚不处理
        if height < 0 {
            return
        }
        
        //可以根据高度设置刷新控件的frame
        self.frame = CGRect(x: 0,
                            y: -height,
                            width: sv.bounds.width,
                            height: height)
        
        //传递父视图高度,如果正在刷新中，不传递，如果刷新中下拉传递高度，会使袋鼠小时
        //把代码放在最合适的位置
        if refreshView.refreshState != .WillRefresh {
            refreshView.parentViewHeight = height
        }
        
        //判读临界点 - 只需要判断一次
        if sv.isDragging {
            
            if height > ZHSRefreshOffset && (refreshView.refreshState == .Normol){
                print("放手刷新")
                refreshView.refreshState = .Pulling
                
                
            }else if height <= ZHSRefreshOffset && (refreshView.refreshState == .Pulling){
                print("继续使劲、、、")
                refreshView.refreshState = .Normol
            }
        }else{
            //放手 - 判断是否超过临界点
            if refreshView.refreshState == .Pulling {
                print("准备开始刷新")
                beginRefreshing()//取代下面重复代码
                
                //发送刷新数据事件
                sendActions(for: .valueChanged)
                
                //刷新结束之后，将状态修改为 。normol才能继续响应刷新
//                refreshView.refreshState = .WillRefresh
                //让整个刷新视图能够显示出来
                //解决方法：修改表格contentinset
//                var inset = sv.contentInset
//                inset.top += ZHSRefreshOffset
//                
//                sv.contentInset = inset
                
                
                
            }
        }
    }
    
    
    /// 开始刷新
    func beginRefreshing(){
        
        //判读父视图
        guard let sv = scrollView else {
            return
        }
        
        //判断是否正在刷新，如果正在刷新，直接返回
        if refreshView.refreshState == .WillRefresh {
            return
        }
        
        //设置刷新视图的状态
        refreshView.refreshState = .WillRefresh
        
        //调整表格的间距
        //让整个刷新视图能够显示出来
        //解决方法：修改表格contentinset
        var inset = sv.contentInset
        inset.top += ZHSRefreshOffset
        sv.contentInset = inset
        
        //设置刷新视图的父视图高度
        refreshView.parentViewHeight = ZHSRefreshOffset
        
        //如果开始调用beginRefreshing会重复发送刷新事件
        //sendActions(for: .valueChanged)
    
    }
    
    /// 结束刷新
    func endRefreshing(){
        
        guard let sv = scrollView else {
            return
        }
        
        //判断状态，是否正在刷新，如果不是，直接返回 --- 防止重复调用endRefreshing而重复调整表格间距
        if refreshView.refreshState != .WillRefresh {
            return
        }
        
        //恢复刷新视图的状态
        refreshView.refreshState = .Normol
        //恢复表格视图 contentinset
        var  inset = sv.contentInset
        inset.top -= ZHSRefreshOffset
        
        sv.contentInset = inset
        
    }

    
}

extension ZHSRefreshControl{
    
    func setupUI(){
        
        backgroundColor = superview?.backgroundColor
        
        //设置超出边界不显示，因为在setupui方法时，视图本来没有大小的，要拖拽才有
        //clipsToBounds = true
        
        //添加刷新视图
        addSubview(refreshView)
        
        //自动布局 - 设置xib控件的自动布局，需要指定宽高的约束
        //提示：ios程序员，一定要会原生的写法，因为如果自己开发框架，不能用任何的自动布局
        refreshView.translatesAutoresizingMaskIntoConstraints = false
        
        addConstraint(NSLayoutConstraint(item: refreshView,
                                         attribute: .centerX,
                                         relatedBy: .equal,
                                         toItem: self,
                                         attribute: .centerX,
                                         multiplier: 1.0,
                                         constant: 0))
        addConstraint(NSLayoutConstraint(item: refreshView,
                                         attribute: .bottom,
                                         relatedBy: .equal,
                                         toItem: self,
                                         attribute: .bottom,
                                         multiplier: 1.0,
                                         constant: 0))
        addConstraint(NSLayoutConstraint(item: refreshView,
                                         attribute: .width,
                                         relatedBy: .equal,
                                         toItem: nil,
                                         attribute: .notAnAttribute,
                                         multiplier: 1.0,
                                         constant: refreshView.bounds.width))
        addConstraint(NSLayoutConstraint(item: refreshView,
                                         attribute: .height,
                                         relatedBy: .equal,
                                         toItem: nil,
                                         attribute: .notAnAttribute,
                                         multiplier: 1.0,
                                         constant: refreshView.bounds.height))
    }

}


