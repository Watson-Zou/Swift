//
//  ZHSRefreshView.swift
//  自定上下拉刷新
//
//  Created by Watson on 2017/4/7.
//  Copyright © 2017年 Watson. All rights reserved.
//

import UIKit

/// 刷新视图 - 负责刷新相关的ui显示和动画
class ZHSRefreshView: UIView {

    //刷新状态
    /*
        ios系统中UIView封装的旋转动画
     - 默认顺时针旋转
     - 就近原则
     - 如果要想实现相同方向旋转，需要调整一个非常小的数字
     - 如果想实现360度旋转，需要核心动画 CABaseAnimation
     
     */
    var refreshState:ZHSRefreshState = .Normol{
    
        didSet{
            switch refreshState {
            case .Normol:
                //恢复状态
                tipIcon?.isHidden = false
                indicator?.stopAnimating()
                
                tipLabel?.text = "继续使劲拉..."
                //添加动画
                UIView .animate(withDuration: 0.25, animations: {
                    //箭头恢复初始状态
                    //因为这里时闭包，所以要用 self.tipIcon
                    self.tipIcon?.transform = CGAffineTransform.identity
                })
            case .Pulling:
                tipLabel?.text = "放手就刷新..."
                //添加动画
                UIView .animate(withDuration: 0.25, animations: { 
                    //箭头旋转180度
                    //因为这里时闭包，所以要用 self.tipIcon
                    self.tipIcon?.transform = CGAffineTransform(rotationAngle: CGFloat(M_PI + 0.001))
                })
                
            case .WillRefresh:
                tipLabel?.text = "正在刷新中..."
                //隐藏提示图标
                tipIcon?.isHidden = true
                
                //显示菊花
                indicator?.startAnimating()
            }
        }
    }
    
    
    /*
     把xib拉的熟悉改为 ？可选项，因为美团的ZHSMeituanRefreshView继承ZHSRefreshView，但是美团的view里面没有下面的属性，
     */
    
    //父视图高度 - 传给子类
    //为了刷新控件不需要关心当前具体的刷新视图是谁 --- 解耦
    var parentViewHeight:CGFloat = 0
    
    /// 指示图标
    @IBOutlet weak var tipIcon: UIImageView?
    /// 提示标签
    @IBOutlet weak var tipLabel: UILabel?
    /// 指示器
    @IBOutlet weak var indicator: UIActivityIndicatorView?
    
    //类方法
    class func refreshView()->ZHSRefreshView{
        
        let nib = UINib(nibName: "ZHSMeituanRefreshView", bundle: nil)
        
        //类型转换 as!
        return nib.instantiate(withOwner: nil, options: nil)[0] as! ZHSRefreshView
        
        
    }
    

}
