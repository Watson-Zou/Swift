//
//  WeiBoCommon.swift
//  新浪微博
//
//  Created by Watson on 2017/3/16.
//  Copyright © 2017年 Watson. All rights reserved.
//

import Foundation

//类似于oc的pch

//MARK: - 应用程序信息
//应用程序ID
let WBAppKey = "1708346684"
//应用程序加密信息(开发者可以申请修改)
let WBAppSecret = "25942f1a0e4cab13f27ee9a0e366a48f"
//回调地址 - 登录完成跳转的url，参数以get形式拼接
let WBRedirectURL = "http://baidu.com"

//MARK:-全局通知定义
//用户需要登录通知
let WBUserShouldLoginNotification = "WBUserShouldLoginNotification"

//用户登录成功通知
let WBUserLoginSuccessNotification = "WBUserLoginSuccessNotification"

//MARK:微博配图视图常量
//配图视图外侧的间距
let WBStatusPictureViewOutterMargin = CGFloat(12)
//配图视图内部图像视图的间距
let WBStatusPictureViewInnerMargin = CGFloat(3)
//视图的宽度
let WBStatusPictureViewWidth = UIScreen.cz_screenWidth() - 2 * WBStatusPictureViewOutterMargin
//每个item默认的宽度
let WBStatusPictureItemWidth = (WBStatusPictureViewWidth - 2 * WBStatusPictureViewInnerMargin) / 3


