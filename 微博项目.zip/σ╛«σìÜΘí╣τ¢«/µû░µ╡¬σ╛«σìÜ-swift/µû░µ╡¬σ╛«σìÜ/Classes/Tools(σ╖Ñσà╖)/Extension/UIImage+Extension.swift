//
//  UIImage+Extension.swift
//  新浪微博
//
//  Created by Watson on 2017/3/21.
//  Copyright © 2017年 Watson. All rights reserved.
//

import UIKit

extension UIImage{
    
    /// 创建头像
    ///
    /// - Parameters:
    ///   - size: 尺寸
    ///   - backColor: 背景颜色 默认白色
    ///   - lineColor: 线条颜色 默认浅灰色
    /// - Returns: 返回的图像
    func cz_avatarImage(size:CGSize?,backColor:UIColor = UIColor.white,lineColor:UIColor = UIColor.lightGray) -> UIImage? {
        
        var size = size
        
        if size == nil {
            size = self.size
        }
        let rect = CGRect(origin: CGPoint(), size: size!)
        
        //添加图像上下文
        UIGraphicsBeginImageContextWithOptions(rect.size, true, 0)
        
        backColor.setFill()
        UIRectFill(rect)
        
        //添加路径
        let path = UIBezierPath(ovalIn: rect)
        path.addClip()
        
        //绘图
        draw(in: rect)
        
        //画边框
        let ovalPath = UIBezierPath(ovalIn: rect)
        ovalPath.lineWidth = 2
        lineColor.setStroke()
        ovalPath.stroke()
        
        //取得结果
        let result = UIGraphicsGetImageFromCurrentImageContext()
        
        //关闭上下文
        UIGraphicsEndImageContext()
        
        return result
        
        
    }
    
}
