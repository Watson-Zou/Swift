//
//  UIImageView+WebImage.swift
//  新浪微博
//
//  Created by Watson on 2017/3/21.
//  Copyright © 2017年 Watson. All rights reserved.
//

import SDWebImage

extension UIImageView{
    
    /// 隔离UIImageView设置图像函数
    ///
    /// - Parameters:
    ///   - urlString:  urlString
    ///   - placeholderImage: 占位图片
    ///   - isAvatar: 是否头像
    func cz_setImage(urlString:String?,placeholderImage:UIImage?,isAvatar:Bool = false){
    
        //处理url 先判断urlString是否有值，再判断是否处理url成功
        guard let urlString = urlString,
            let url = URL(string: urlString) else {
            
            //设置占位的图片
            image = placeholderImage
            
            return
        }
        
        //可选项只是用在swift，oc有的时候用！，同样可以传入nil 
        //[weak self]防止循环引用
        sd_setImage(with: url,placeholderImage: placeholderImage,options: [],progress: nil){ [weak self](image,_,_,_) in
            
            //完成回调，判断是否时头像
            if isAvatar{
                
               self?.image = image?.cz_avatarImage(size: self?.bounds.size)
            
            }
        }
        
        
    }
    
    
    
    
}
