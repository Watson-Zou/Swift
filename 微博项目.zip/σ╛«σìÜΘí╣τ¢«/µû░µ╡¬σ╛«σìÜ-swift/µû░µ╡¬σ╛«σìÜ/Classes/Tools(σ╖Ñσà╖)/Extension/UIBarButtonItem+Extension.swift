//
//  UIBarButtonItem+Extension.swift
//  新浪微博
//
//  Created by Watson on 2017/3/9.
//  Copyright © 2017年 Watson. All rights reserved.
//

import UIKit

extension UIBarButtonItem{

    //利用便利构造函数抽取UIBarButtonItem
    //创建UIBarButtonItem,字体默认16号
    convenience init(title:String,fontSize:CGFloat = 16,target:Any?,action:Selector,isBack :Bool = false){
    
        let btn:UIButton = UIButton.cz_textButton(title, fontSize: fontSize, normalColor: UIColor.darkGray, highlightedColor: UIColor.orange)

        if isBack {
            let imageName = "navigationbar_back_withtext"
            btn.setImage(UIImage(named:imageName), for: .normal)
            btn.setImage(UIImage(named:imageName+"_highlighted"), for: .highlighted)
            btn.sizeToFit()
        }
        btn.addTarget(target, action: action, for: .touchUpInside)
        
        //实例化 UIBarButtonItem
        self.init(customView:btn)
    }

}
