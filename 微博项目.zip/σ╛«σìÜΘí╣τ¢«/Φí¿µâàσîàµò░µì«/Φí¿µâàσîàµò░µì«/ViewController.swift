//
//  ViewController.swift
//  表情包数据
//
//  Created by Watson on 2017/6/3.
//  Copyright © 2017年 Watson. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var demolable: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()

        //目标： 我[爱你]啊[笑哈哈]
        let string = "我[爱你]啊[笑哈哈][马上有对象]"
        /*
            注意点：应该倒序遍历
         
            我[爱你]啊[笑哈哈]
            r1 = {1,4}
            r2 = {6,5}
         --- 顺序替换，替换了前面的之后，后面的范围会失效
         --- 倒序替换，一次循环可以把所有的图片全部替换完成
         */
        
        //demolable.attributedText = emotionString(string: string)
        demolable.attributedText = CZEmoticonManager.shared.emotionString(string: string, font: demolable.font)
        
    }
    
    //将给定的字符串转换成属性文本
    // 关键点：按照匹配结果倒序替换属性文本
    func emotionString(string:String) -> NSAttributedString {
        
        let attrString = NSMutableAttributedString(string: string)
        
        //1.建立正则表达式，过滤所有表情文字
        //[] () 都是正则表达式的关键字，如果要参与匹配，需要转义
        
        let pattern = "\\[.*?\\]"
        guard let regx = try? NSRegularExpression(pattern: pattern, options: []) else {
            return attrString
        }
        
        //2.匹配所有项
        let matches = regx.matches(in: string, options: [], range: NSRange(location: 0, length: attrString.length))
        
        //3.遍历所有匹配结果(倒序)
        for m in  matches.reversed(){
            let r  = m.rangeAt(0)
            let subStr = (attrString.string as NSString).substring(with: r)
            
            //1>使用substring查找对应的表情符号
            if let em = CZEmoticonManager.shared.findEmoticon(string: subStr) {
                //2>使用表情符号中的属性文本，替换原有的属性文本
                attrString.replaceCharacters(in: r, with: em.imageText(font: demolable.font))
            }
            
            
        }
        
        
        
        return attrString
        
    }
    
    
    func demo()  {
        // --- 测试单例 ---
        let m1 = CZEmoticonManager.shared
        print(m1.package)
        
        // --- 测试表情图像 ---
        print(CZEmoticonManager.shared.package.last?.emoticons.first?.image)
        print(CZEmoticonManager.shared.package.last?.emoticons.first)
        
        // --- 测试查找表情 ---
        print(CZEmoticonManager.shared.findEmoticon(string: "[马上有对象]"))
        
        // --- 测试直接生成表情属性文本 ---
        let em = CZEmoticonManager.shared.findEmoticon(string: "[马上有对象]")
        demolable.attributedText = em?.imageText(font: demolable.font)
        

    }
    


}

