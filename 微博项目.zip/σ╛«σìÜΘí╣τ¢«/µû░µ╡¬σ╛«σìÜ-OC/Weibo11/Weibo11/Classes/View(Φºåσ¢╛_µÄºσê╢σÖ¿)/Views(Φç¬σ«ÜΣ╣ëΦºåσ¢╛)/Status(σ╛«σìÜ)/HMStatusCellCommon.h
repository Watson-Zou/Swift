//
//  HMStatusCellCommon.h
//  Weibo11
//
//  Created by 刘凡 on 15/12/9.
//  Copyright © 2015年 itheima. All rights reserved.
//  微博 Cell 常量定义

#import "HMStatusViewModel.h"
#import <SDWebImage/UIImageView+WebCache.h>

/// 控件间距
#define kStatusCellMargin       10
/// 头像宽度
#define kStatusCellIconWidth    35
