//
//  HMEmoticonTipView.h
//  Weibo11
//
//  Created by 刘凡 on 15/12/16.
//  Copyright © 2015年 itheima. All rights reserved.
//

#import <UIKit/UIKit.h>
@class HMEmoticon;

/// 表情提示视图
@interface HMEmoticonTipView : UIImageView

@property (nonatomic) HMEmoticon *emoticon;

@end
