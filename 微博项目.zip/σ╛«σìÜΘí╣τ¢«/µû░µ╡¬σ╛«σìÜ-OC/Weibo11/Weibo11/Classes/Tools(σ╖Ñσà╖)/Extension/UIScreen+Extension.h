//
//  UIScreen+Extension.h
//  Weibo11
//
//  Created by 刘凡 on 15/12/8.
//  Copyright © 2015年 itheima. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIScreen (Extension)

+ (CGSize)ff_screenSize;
+ (BOOL)ff_isRetina;
+ (CGFloat)ff_scale;

@end
